package restAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;


public class OauthTokenFromPostman {
	
	@Test
	public void getToken() {
		Response resp=RestAssured.given()
				//.auth()
				//.oauth2("cab8245e632f0fb88a1e78c4020a38f4c600430f")
				.formParam("client_id","d5450d74cdb0b65")
				.formParam("client_secret", "fc92a537f3e8c0b07c4233c6a8d417bd0e6a2e1a")
				.formParam("grant_type", "Authorization code")
				.formParam("Callback URL", "https://www.getpostman.com/oauth2/callback")
				.formParam("Auth URL", "https://api.imgur.com/oauth2/authorize")
				.formParam("Access Token URL", "https://api.imgur.com/oauth2/token")
				.formParam("Authorization", "Bearer 5e81baf05f1a195b345107783a1e7c815e6d2a40")
				
			.get("https://api.imgur.com/3/account/me/images");
		
		
		
			
		//resp.prettyPrint();
		System.out.println(resp.jsonPath().prettify());
		
		//System.out.println("The stust code is "+resp.getStatusCode());
		//System.out.println("The stust code is "+resp.getBody().asString());
				
	}
}
