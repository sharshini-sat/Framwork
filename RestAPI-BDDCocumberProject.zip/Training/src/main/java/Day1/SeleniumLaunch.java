package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumLaunch {
	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.chrome.driver",
				".\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
				wd.get("https://www.google.com/");
				wd.manage().window().maximize();
				Thread.sleep(5000);
				// Extracting Navigated URL
				System.out.println("URL:" + wd.getCurrentUrl());
				// Extracting Title
				System.out.println("TITLE:" + wd.getTitle());
				// Closing Chrome
//				wd.close();
				//to: yahoo
				//Back
				//Forward
				//Refresh
				wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
				Thread.sleep(5000);
				
				wd.close();
				
		
	}

}
