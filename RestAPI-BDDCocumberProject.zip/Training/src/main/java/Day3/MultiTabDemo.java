package Day3;

import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultiTabDemo {
	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.chrome.driver",
				".\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("https://www.google.com");
		wd.manage().window().maximize();
		Thread.sleep(5000);
//		wd.findElement(By.tagName("body")).sendKeys(Keys.chord( Keys.CONTROL, "t" ));
		((JavascriptExecutor) wd).executeScript("window.open()");
		Set<String> tabs=wd.getWindowHandles();
		for(String eachTab:tabs) {
			System.out.println(eachTab);
			wd.switchTo().window(eachTab);
		}
		wd.get("https://www.google.com/");
		
		wd.close();
		
	}
}
