package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class GoogleSearch {

	@Given("I want to launch google.com")
	public void i_want_to_launch_google_com() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("I am inside google.com");
	}

	@When("I enter text {string}")
	public void i_enter_text(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("I have entered the "+ string);
	}
}
