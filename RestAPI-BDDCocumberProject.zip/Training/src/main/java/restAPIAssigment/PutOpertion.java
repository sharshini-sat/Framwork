package restAPIAssigment;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PutOpertion {
	@Test
    void updateUserDetailsintoList() {
		PropertyConfigurator.configure("C:\\Users\\Sharshini\\eclipse-workspace\\Training\\src\\main\\log4j.properties");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.info("Method:Updating user details into List");
		log.debug("Hello Log4J from Logger as Debug");
		JSONObject requestparams = new JSONObject();
		
		log.info("Updating User Name and Job details into List");
		    requestparams.put("name", "sharshini");
		    requestparams.put("job", "leader");
		    
		    RequestSpecification request = RestAssured.given();
		    request.body(requestparams);
		    
		    Response response = request.put("https://reqres.in/api/users");
		 
		   System.out.println("Name: "+ requestparams.get("name"));
		   System.out.println("job: "+ requestparams.get("job"));
		    response.prettyPrint();
		    
		    System.out.println("The status code is "+response.getStatusCode());
		    log.info("PutOpertion Class is Executed Successfully");
	}
}
