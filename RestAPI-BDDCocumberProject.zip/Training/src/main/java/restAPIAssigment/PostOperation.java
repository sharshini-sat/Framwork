package restAPIAssigment;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostOperation {
	static String name= "morpheus";
	static String job= "leader";
@Test
public void createUserInList() {
	PropertyConfigurator.configure("C:\\Users\\Sharshini\\eclipse-workspace\\Training\\src\\main\\log4j.properties");
	Logger log=Logger.getLogger("devpinoyLogger");
	log.info("Method:Creating user details in List");
	log.debug("Hello Log4J from Logger as Debug");
	RestAssured.baseURI = "https://reqres.in/api/users";
	
	JSONObject requestparams = new JSONObject();
	
	log.info("Adding User Name and Job details into List");
	    requestparams.put("name", "morpheus");
	    requestparams.put("job", "leader");
	    
	    RequestSpecification request = RestAssured.given();
	    request.body(requestparams);
	    
	    Response response = request.post("https://reqres.in/api/users");
	    System.out.println("Name: "+ requestparams.get("name"));
	    System.out.println("job: "+ requestparams.get("job"));
	    
	    response.prettyPrint();
	    System.out.println("The status code is "+response.getStatusCode());
	    log.info("PostOperation Class is Executed Successfully");
	    
}
}


