package Day4Testng;

import org.testng.annotations.Test;

public class MyFirstTestNGTest {

	@Test
	public void firstTestngMethod() {
		System.out.println("Hello TestNG");
	}
	@Test
	public void secondTestngMethod() {
		System.out.println("Hello TestNG second");
	}
}
