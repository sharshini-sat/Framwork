package stepDefinition;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteTask {
	int statusIS;
	@Given("To delete user details from API")
	public void to_delete_user_details_from_api() {
		System.out.println("Deleting users details from the list"); 
	}

	@When("Delete user details with id")
	public void delete_user_details_with_id() {
		PropertyConfigurator.configure("C:\\Users\\Sharshini\\eclipse-workspace\\Training\\src\\main\\log4j.properties");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.info("Method:Deletingting user details from List");
		log.debug("Hello Log4J from Logger as Debug");
		Response resp=RestAssured.given()
				.delete("https://reqres.in/api/users2");
		resp.prettyPrint();
		System.out.println("The stust code is "+resp.getStatusCode());
		log.info("DeleteOpertion Class is Executed Successfully");
	    
	}

	@Then("User details should get delete and get success status code")
	public void user_details_should_get_delete_and_get_success_status_code() {
		System.out.println("The stust code is "+statusIS);
	}

}
