package stepDefinition;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetTask {
	
	 int statusIS;
	
	@Given("Get list of users from API")
	public void get_list_of_users_from_api() {
	    System.out.println("Get users details from the list for page 2");
	    
	}

	@When("Get only page2 user details")
	public void get_only_page2_user_details() {
		PropertyConfigurator.configure("C:\\Users\\Sharshini\\eclipse-workspace\\Training\\src\\main\\log4j.properties");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.info("Method:Getting User List");
		log.debug("Hello Log4J from Logger as Debug");
		Response resp=RestAssured.given()
				.get("https://reqres.in/api/users?page=2");
				resp.prettyPrint();
				System.out.println("The stust code is "+resp.getStatusCode());
				 statusIS=resp.getStatusCode();
				log.info("GetOpertion Class is Executed Successfully");
	}

	@Then("should get users list and success status code")
	public void should_get_users_list_and_success_status_code() {
		System.out.println("The stust code is "+statusIS);
	}


}
