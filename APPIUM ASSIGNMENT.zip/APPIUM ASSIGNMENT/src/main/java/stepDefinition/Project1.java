package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Project1 {
	WebDriver wd;
	
	@Given("Open Google URL")
	public void open_google_url() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				".\\chromedriver.exe");
		 wd = new ChromeDriver();
		// Navigating to google
				wd.get("https://www.google.com/");
				wd.manage().window().maximize();
				Thread.sleep(5000);
	}

	@When("I search the text {string}")
	public void i_search_the_text(String string) throws InterruptedException {
		System.out.println("I am inside google search page");
		wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
		Thread.sleep(5000);
	}

	@Then("I click on the first link available")
	public void i_click_on_the_first_link_available() {
		System.out.println("First Link is :"+wd.findElement(By.xpath("(//a/h3)[1]")).getText());
		wd.close();
	}
}
