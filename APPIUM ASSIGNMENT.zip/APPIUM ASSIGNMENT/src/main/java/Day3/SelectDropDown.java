package Day3;


import org.eclipse.jetty.io.ssl.ALPNProcessor.Client;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropDown {
	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.chrome.driver",
				".\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		WebElement we=wd.findElement(By.tagName("select"));
		Select sel= new Select(we);
		sel.selectByIndex(2);
		sel.selectByValue("ARM");
		sel.selectByVisibleText("Bahamas");
		WebElement we1=wd.findElement(By.tagName("p"));
		//we1.click();
		Select sel1= new Select(we1);
		sel1.selectByIndex(2);
		
		wd.close();
		
	}

}
