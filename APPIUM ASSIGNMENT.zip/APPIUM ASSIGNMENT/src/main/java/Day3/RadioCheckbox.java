package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioCheckbox {
	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.chrome.driver",
				".\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		List<WebElement>  listLinks=wd.findElements(By.xpath("//label[text()='Two']"));
		
		for(WebElement eachElement:listLinks) {
			System.out.println(eachElement.isSelected());// Checkbox/radio selection
			////in case isSelected returns false/true then go for alternative---any other attribute
			//eachElement.getAttribute("value")
			System.out.println(eachElement.isDisplayed());
			System.out.println(eachElement.isEnabled());
			eachElement.click();
			System.out.println(eachElement.isSelected());
			
		}
		wd.close();
		
	}

}
