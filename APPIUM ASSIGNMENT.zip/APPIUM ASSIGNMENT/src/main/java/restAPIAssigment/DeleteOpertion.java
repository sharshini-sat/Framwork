package restAPIAssigment;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteOpertion {
	@Test
	public void removeUserFromList() {
		PropertyConfigurator.configure("C:\\Users\\Sharshini\\eclipse-workspace\\Training\\src\\main\\log4j.properties");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.info("Method:Deletingting user details from List");
		log.debug("Hello Log4J from Logger as Debug");
		Response resp=RestAssured.given()
				.delete("https://reqres.in/api/users2");
		resp.prettyPrint();
		System.out.println("The stust code is "+resp.getStatusCode());
		log.info("DeleteOpertion Class is Executed Successfully");
	    
	}
}
