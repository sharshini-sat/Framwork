package Appium;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.TapOptions;
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
public class Extracting_X_and_Y_element {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		String sFile = "C:\\Users\\Sharshini\\Downloads\\ApiDemos-debug.apk";

		// To create an object of Desired Capabilities
		DesiredCapabilities capability = new DesiredCapabilities();
		// OS Name
		capability.setCapability("device", "Android");
		capability.setCapability(CapabilityType.BROWSER_NAME, "");
		// Mobile OS version. In My case its running on Android 4.2
		capability.setCapability(CapabilityType.VERSION, "11.0");
		capability.setCapability("app", sFile);
		// To Setup the device name
		capability.setCapability("deviceName", "Pixel 2 API 30 2");
		capability.setCapability("platformName", "Android");
		// set the package name of the app
		capability.setCapability("app-package", "io.appium.android.apis");
		// set the Launcher activity name of the app
		capability.setCapability("app-activity", ".ApiDemos");
		// driver object with new Url and Capabilities
		AppiumDriver driver = new AppiumDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capability);
		Thread.sleep(2000);
		TouchAction touch=new TouchAction(driver);
		List<MobileElement> listElement=(List<MobileElement>)driver.findElementsById("android:id/text1");

		//Extracting X and Y element
		System.out.println("Value of Y is "+listElement.get(0).getLocation().getY());
		System.out.println("Value of x is "+listElement.get(0).getLocation().getX());
		
		//Coordinates for First Element
				int x1=listElement.get(0).getLocation().getX() + 
					   listElement.get(0).getSize().getWidth()/2;
				int y1=listElement.get(0).getLocation().getY() + 
						   listElement.get(0).getSize().getHeight()/2;

				int x2=listElement.get(5).getLocation().getX() + 
					   listElement.get(5).getSize().getWidth()/2;
				int y2=listElement.get(5).getLocation().getY() + 
						   listElement.get(5).getSize().getHeight()/2;
				//with pointer
				touch.press(point(x1,y1))
				.waitAction(waitOptions(Duration.ofSeconds(2)))
				.moveTo(point(x2,y2))
				.release()
				.perform();
	}

}


