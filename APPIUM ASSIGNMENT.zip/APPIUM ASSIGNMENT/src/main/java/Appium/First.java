package Appium;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class First {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		String sFile = "C:\\Users\\Sharshini\\Downloads\\ApiDemos-debug.apk";
		System.out.println("Reached here1");

		// To create an object of Desired Capabilities
		DesiredCapabilities capability = new DesiredCapabilities();
//OS Name
		capability.setCapability("device", "Android");
		capability.setCapability(CapabilityType.BROWSER_NAME, "");
//Mobile OS version. In My case its running on Android 4.2
		capability.setCapability(CapabilityType.VERSION, "11.0");
		capability.setCapability("app", sFile);
//To Setup the device name
		//capability.setCapability("deviceName", "ce10171a5529531f03");
		capability.setCapability("deviceName", "Pixel XL API 30");
		capability.setCapability("platformName", "Android");
		System.out.println("Reached here2");
//set the package name of the app
		capability.setCapability("app-package", "io.appium.android.apis");
		System.out.println("Reached here3");
		// set the Launcher activity name of the app
		capability.setCapability("app-activity", ".ApiDemos");
		System.out.println("Reached here4");
//driver object with new Url and Capabilities
		WebDriver driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capability);
		System.out.println("Reached here");
		Thread.sleep(2000);
	}

}
