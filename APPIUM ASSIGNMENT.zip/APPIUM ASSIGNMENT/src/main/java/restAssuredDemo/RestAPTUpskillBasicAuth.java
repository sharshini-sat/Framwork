package restAssuredDemo;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestAPTUpskillBasicAuth {
@Test
public void oAuthDemo() {
	Response resp=RestAssured.given()
			.baseUri("http://rest-api.upskills.in/api/rest_admin/oauth2/token/client_credentials")
			.accept(ContentType.JSON)//.header()
			.header("Authorization","Basic ZGVtb19vYXV0aF9jbGllbnQ6ZGVtb19vYXV0aF9zZWNyZXQ=")
	.when()
		.post();
resp.prettyPrint();
}
}
